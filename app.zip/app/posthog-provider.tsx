"use client";

import { PostHogProvider as PostHogReactProvider } from "posthog-js/react";

const posthogKey = process.env.NEXT_PUBLIC_POSTHOG_KEY;
const posthogHost = process.env.NEXT_PUBLIC_POSTHOG_HOST;

type PostHogProviderProps = {
  children: React.ReactNode;
};

export function PostHogProvider({ children }: PostHogProviderProps) {
  if (!posthogKey) {
    return <>{children}</>;
  }

  return (
    <PostHogReactProvider
      apiKey={posthogKey}
      options={{
        api_host: posthogHost,
        capture_pageview: "history_change",
      }}
    >
      {children}
    </PostHogReactProvider>
  );
}
